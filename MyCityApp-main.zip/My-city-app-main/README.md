# My City App
This application is developed using kotlin in android studio. This is an android native mobile application where you can see my favorite store in my city.
I have JetPack  Composable and Material Theme Builder for design and theme, style. Used NavHost for navvigation and bachHander for this project

![My city app (1)](https://github.com/user-attachments/assets/487230ff-4a8e-4a90-8a60-c1eb30ceaecb)
